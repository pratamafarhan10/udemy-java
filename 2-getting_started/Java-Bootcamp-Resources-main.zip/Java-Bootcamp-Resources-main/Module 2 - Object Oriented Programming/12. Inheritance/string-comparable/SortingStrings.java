public class SortingStrings {
    public static void main(String[] args) {
        String john = "John";
        String amy = "Amy";
        String jane = "Jane";
        
    }
}
