public class Solution {
//Before looking at the solution, try the challenge on your own. 
        public static void main(String[] args) {
    
            System.out.println(" SSS     A  ");
            System.out.println("S   S   A A ");
            System.out.println("S      A   A");
            System.out.println(" SSS   AAAAA");
            System.out.println("    S  A   A");
            System.out.println("S   S  A   A");
            System.out.println(" SSS   A   A");

        }

}